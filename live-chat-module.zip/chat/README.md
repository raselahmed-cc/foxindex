# Live chat module — FoxIndex

Drop-in for the NestJS + Next.js stack. Uses the `chat_conversations` / `chat_messages`
tables from `indexing_saas_schema.sql`.

## Backend (`backend/chat/`)
- `chat.gateway.ts` — Socket.io gateway on namespace `/chat`, JWT auth on connect, Redis adapter.
- `chat.service.ts` — persistence, RBAC (client = own thread, manager = assigned clients, admin = all), inbox, convert-to-ticket.
- `presence.service.ts` — online/offline via Redis counters with TTL heartbeat.
- `chat-offline.processor.ts` — BullMQ worker: email + WhatsApp when the recipient is offline (deduped per 10 min).
- `ws-role.guard.ts` — role guard for socket events.

Install: `npm i @nestjs/websockets @nestjs/platform-socket.io socket.io @socket.io/redis-adapter ioredis`

Register `ChatModule` in `AppModule`. `RedisService` must expose `client`, `pub`, `sub` (three ioredis instances —
pub/sub connections cannot be reused for commands).

Add a `heartbeat` handler if you want strict presence:
```ts
@SubscribeMessage('heartbeat') hb(@ConnectedSocket() s: AuthedSocket) { return this.presence.heartbeat(s.user.id); }
```

## Frontend (`frontend/`)
- `useChat.ts` — hook: `open()`, `send()`, `typing()`, `markRead()`, `convertToTicket()`, plus `messages`, `peerOnline`, `peerTyping`, `totalUnread`.
- `useInbox()` — staff conversation list, auto-refreshes on new messages.
- `ChatWidget.tsx` — floating widget matching the design file's `.chat-box` / `.chat-fab` classes.

Install: `npm i socket.io-client`

Env: `NEXT_PUBLIC_API_URL`, and on the API `WEB_ORIGIN`, `JWT_SECRET`.

## Events
| Client → server | Server → client |
|---|---|
| `conversation:open {clientId?}` → `{conversation, messages}` | `ready {unread}` |
| `message:send {conversationId, body, attachments}` | `message:new <message>` |
| `typing {conversationId, typing}` | `typing {userId, typing}` |
| `read {conversationId}` | `read {conversationId, by, at}` |
| `inbox:list` (staff) | `presence {userId, online}` |
| `conversation:toTicket {conversationId, subject}` | `unread {conversationId}` |

## Notes
- Sockets only join one `conv:*` room at a time; the manager inbox opens threads one by one.
- Unread counts live in Redis hash `unread:<userId>`, cleared on `read`.
- Attachments: upload via your existing REST upload endpoint first, then pass `{name,url}` in `message:send`.
- Scale: Redis adapter means you can run several API pods; sticky sessions are not required with `transports: ['websocket']`.
