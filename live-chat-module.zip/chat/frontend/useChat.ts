'use client';
import { useEffect, useRef, useState, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';

export type ChatMessage = {
  id: string; conversationId: string; senderId: string; senderName?: string;
  body: string; attachments: { name: string; url: string }[]; readAt: string | null; createdAt: string;
};

type Opts = { token: string; clientId?: string /* staff only: which client's thread */ };

let shared: Socket | null = null; // one socket per tab, shared by widget + inbox

function getSocket(token: string) {
  if (!shared) {
    shared = io(`${process.env.NEXT_PUBLIC_API_URL}/chat`, {
      auth: { token }, withCredentials: true, transports: ['websocket'],
    });
    // heartbeat keeps the Redis presence key alive
    setInterval(() => shared?.emit('heartbeat'), 25_000);
  }
  return shared;
}

export function useChat({ token, clientId }: Opts) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [peerOnline, setPeerOnline] = useState(false);
  const [peerTyping, setPeerTyping] = useState(false);
  const [unread, setUnread] = useState<Record<string, number>>({});
  const [connected, setConnected] = useState(false);
  const sock = useRef<Socket>();
  const typingTimer = useRef<ReturnType<typeof setTimeout>>();

  useEffect(() => {
    const s = (sock.current = getSocket(token));

    const onConnect = () => setConnected(true);
    const onDisconnect = () => setConnected(false);
    const onReady = (p: { unread: Record<string, number> }) => setUnread(p.unread);
    const onNew = (m: ChatMessage) => {
      setMessages(prev => (m.conversationId === conversationId ? [...prev, m] : prev));
    };
    const onUnread = (p: { conversationId: string }) => {
      if (p.conversationId !== conversationId) setUnread(u => ({ ...u, [p.conversationId]: (u[p.conversationId] ?? 0) + 1 }));
    };
    const onPresence = (p: { online: boolean }) => setPeerOnline(p.online);
    const onTyping = (p: { typing: boolean }) => setPeerTyping(p.typing);
    const onRead = (p: { at: string }) => setMessages(prev => prev.map(m => (m.readAt ? m : { ...m, readAt: p.at })));

    s.on('connect', onConnect); s.on('disconnect', onDisconnect); s.on('ready', onReady);
    s.on('message:new', onNew); s.on('unread', onUnread); s.on('presence', onPresence);
    s.on('typing', onTyping); s.on('read', onRead);
    if (s.connected) setConnected(true);

    return () => {
      s.off('connect', onConnect); s.off('disconnect', onDisconnect); s.off('ready', onReady);
      s.off('message:new', onNew); s.off('unread', onUnread); s.off('presence', onPresence);
      s.off('typing', onTyping); s.off('read', onRead);
    };
  }, [token, conversationId]);

  /** Open the thread (client: own; staff: pass clientId) */
  const open = useCallback(async () => {
    const res = await sock.current!.emitWithAck('conversation:open', { clientId });
    setConversationId(res.conversation.id);
    setMessages(res.messages);
    setUnread(u => { const c = { ...u }; delete c[res.conversation.id]; return c; });
  }, [clientId]);

  const send = useCallback(async (body: string, attachments: ChatMessage['attachments'] = []) => {
    if (!conversationId) return;
    await sock.current!.emitWithAck('message:send', { conversationId, body, attachments });
    sock.current!.emit('typing', { conversationId, typing: false });
  }, [conversationId]);

  /** Call on every input change; auto-sends typing:false after 2s idle */
  const typing = useCallback(() => {
    if (!conversationId) return;
    sock.current!.emit('typing', { conversationId, typing: true });
    clearTimeout(typingTimer.current);
    typingTimer.current = setTimeout(() => sock.current!.emit('typing', { conversationId, typing: false }), 2000);
  }, [conversationId]);

  const markRead = useCallback(() => {
    if (conversationId) sock.current!.emit('read', { conversationId });
  }, [conversationId]);

  const convertToTicket = useCallback((subject: string) =>
    sock.current!.emitWithAck('conversation:toTicket', { conversationId, subject }), [conversationId]);

  const totalUnread = Object.values(unread).reduce((a, b) => a + b, 0);

  return { connected, conversationId, messages, peerOnline, peerTyping, unread, totalUnread, open, send, typing, markRead, convertToTicket };
}

/** Staff inbox list; use alongside useChat for the selected thread */
export function useInbox(token: string) {
  const [items, setItems] = useState<any[]>([]);
  const refresh = useCallback(async () => setItems(await getSocket(token).emitWithAck('inbox:list', {})), [token]);
  useEffect(() => {
    refresh();
    const s = getSocket(token);
    s.on('unread', refresh); s.on('message:new', refresh);
    return () => { s.off('unread', refresh); s.off('message:new', refresh); };
  }, [token, refresh]);
  return { items, refresh };
}
