'use client';
import { useEffect, useRef, useState } from 'react';
import { useChat } from './useChat';

/** Floating widget for the client dashboard. Manager props come from the session. */
export default function ChatWidget({ token, manager }: { token: string; manager: { name: string; whatsapp: string } }) {
  const [openBox, setOpenBox] = useState(false);
  const [text, setText] = useState('');
  const chat = useChat({ token });
  const bottom = useRef<HTMLDivElement>(null);

  useEffect(() => { if (openBox) { chat.open(); } }, [openBox]);           // load history when opened
  useEffect(() => { bottom.current?.scrollIntoView({ behavior: 'smooth' }); if (openBox) chat.markRead(); }, [chat.messages, openBox]);

  const submit = async () => {
    if (!text.trim()) return;
    await chat.send(text);
    setText('');
  };

  const waLink = `https://wa.me/${manager.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent('Hi, I need help with my FoxIndex account.')}`;

  return (
    <>
      {openBox && (
        <div className="card chat-box">
          <div className="ch">
            <span className="avatar">{manager.name.split(' ').map(w => w[0]).join('')}</span>
            <div><b>{manager.name}</b><span>{chat.peerOnline ? 'Online · your account manager' : 'Away · replies within 1 hour'}</span></div>
          </div>
          <div className="cm">
            {chat.messages.length === 0 && <p className="muted">Ask anything about your account or a stuck URL.</p>}
            {chat.messages.map(m => (
              <div key={m.id} className={`bub ${m.senderId !== chat.conversationId && m.senderName === undefined ? '' : ''} ${isMine(m) ? 'me' : ''}`}>{m.body}</div>
            ))}
            {chat.peerTyping && <div className="bub muted">…</div>}
            <div ref={bottom} />
          </div>
          <a className="wa" href={waLink} target="_blank" rel="noreferrer">Prefer WhatsApp? Message {manager.name.split(' ')[0]}</a>
          <div className="ci">
            <input value={text} placeholder="Type a message" onChange={e => { setText(e.target.value); chat.typing(); }}
                   onKeyDown={e => e.key === 'Enter' && submit()} />
            <button className="btn btn-primary btn-sm" onClick={submit} disabled={!chat.connected}>Send</button>
          </div>
        </div>
      )}
      <button className="chat-fab" onClick={() => setOpenBox(o => !o)} aria-label="Open live chat">
        <i />{chat.totalUnread > 0 && <em>{chat.totalUnread}</em>}
      </button>
    </>
  );

  // Mine = sent by the logged-in user; the session user id should be passed in via context in the real app
  function isMine(m: { senderId: string }) { return m.senderId === (globalThis as any).__USER_ID__; }
}
