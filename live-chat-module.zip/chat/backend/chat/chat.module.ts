import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { BullModule } from '@nestjs/bullmq';
import { ChatGateway } from './chat.gateway';
import { ChatService } from './chat.service';
import { PresenceService } from './presence.service';

@Module({
  imports: [
    JwtModule.register({ secret: process.env.JWT_SECRET }),
    BullModule.registerQueue({ name: 'notify' }),
  ],
  providers: [ChatGateway, ChatService, PresenceService],
  exports: [ChatService, PresenceService],
})
export class ChatModule {}
