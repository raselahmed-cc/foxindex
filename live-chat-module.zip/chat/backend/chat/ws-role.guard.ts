import { CanActivate, ExecutionContext, Injectable, mixin } from '@nestjs/common';

export function WsRoleGuard(roles: string[]) {
  @Injectable()
  class Guard implements CanActivate {
    canActivate(ctx: ExecutionContext) {
      const socket = ctx.switchToWs().getClient();
      return roles.includes(socket.user?.role);
    }
  }
  return mixin(Guard);
}
