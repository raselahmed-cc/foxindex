import {
  WebSocketGateway, WebSocketServer, SubscribeMessage, MessageBody,
  ConnectedSocket, OnGatewayConnection, OnGatewayDisconnect, OnGatewayInit,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { createAdapter } from '@socket.io/redis-adapter';
import { JwtService } from '@nestjs/jwt';
import { Logger, UseGuards } from '@nestjs/common';
import { ChatService } from './chat.service';
import { PresenceService } from './presence.service';
import { RedisService } from '../redis/redis.service';
import { WsRoleGuard } from './ws-role.guard';

export interface AuthedSocket extends Socket {
  user: { id: string; role: 'client' | 'manager' | 'admin' | 'superadmin'; name: string; managerId?: string };
}

@WebSocketGateway({
  namespace: '/chat',
  cors: { origin: process.env.WEB_ORIGIN, credentials: true },
})
export class ChatGateway implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() server: Server;
  private log = new Logger(ChatGateway.name);

  constructor(
    private jwt: JwtService,
    private chat: ChatService,
    private presence: PresenceService,
    private redis: RedisService,
  ) {}

  /** Redis adapter so events reach every API instance */
  afterInit(server: Server) {
    server.adapter(createAdapter(this.redis.pub, this.redis.sub));
  }

  async handleConnection(socket: AuthedSocket) {
    try {
      const token = socket.handshake.auth?.token ?? socket.handshake.headers.authorization?.split(' ')[1];
      socket.user = await this.jwt.verifyAsync(token);
    } catch {
      socket.emit('error', { code: 'UNAUTHORIZED' });
      return socket.disconnect(true);
    }
    const { id, role } = socket.user;
    socket.join(`user:${id}`);
    if (role !== 'client') socket.join(`staff:${id}`);

    await this.presence.online(id);
    // Tell the other side of every conversation this user is in
    const peers = await this.chat.peerIdsFor(id, role);
    peers.forEach(p => this.server.to(`user:${p}`).emit('presence', { userId: id, online: true }));

    socket.emit('ready', { unread: await this.chat.unreadCounts(id, role) });
  }

  async handleDisconnect(socket: AuthedSocket) {
    if (!socket.user) return;
    const { id, role } = socket.user;
    const stillOnline = await this.presence.offline(id, socket.id);
    if (!stillOnline) {
      const peers = await this.chat.peerIdsFor(id, role);
      peers.forEach(p => this.server.to(`user:${p}`).emit('presence', { userId: id, online: false }));
    }
  }

  /** Client or staff opens a conversation; returns history + marks read */
  @SubscribeMessage('conversation:open')
  async open(@ConnectedSocket() s: AuthedSocket, @MessageBody() body: { conversationId?: string; clientId?: string }) {
    const conv = await this.chat.openConversation(s.user, body);
    socket_join(s, conv.id);
    await this.chat.markRead(conv.id, s.user.id);
    return { conversation: conv, messages: await this.chat.history(conv.id) };
  }

  @SubscribeMessage('message:send')
  async send(@ConnectedSocket() s: AuthedSocket, @MessageBody() body: { conversationId: string; body: string; attachments?: any[] }) {
    if (!body.body?.trim() && !body.attachments?.length) return { error: 'EMPTY' };
    const msg = await this.chat.sendMessage(s.user, body.conversationId, body.body.trim(), body.attachments ?? []);

    this.server.to(`conv:${body.conversationId}`).emit('message:new', msg);

    // Notify the other party's personal room (for unread badge when thread not open)
    this.server.to(`user:${msg.recipientId}`).emit('unread', { conversationId: body.conversationId });

    // If recipient is offline, queue email + WhatsApp ping (ChatService enqueues to BullMQ)
    if (!(await this.presence.isOnline(msg.recipientId))) {
      await this.chat.notifyOffline(msg);
    }
    return { ok: true, id: msg.id };
  }

  @SubscribeMessage('typing')
  typing(@ConnectedSocket() s: AuthedSocket, @MessageBody() b: { conversationId: string; typing: boolean }) {
    s.to(`conv:${b.conversationId}`).emit('typing', { userId: s.user.id, typing: b.typing });
  }

  @SubscribeMessage('read')
  async read(@ConnectedSocket() s: AuthedSocket, @MessageBody() b: { conversationId: string }) {
    await this.chat.markRead(b.conversationId, s.user.id);
    s.to(`conv:${b.conversationId}`).emit('read', { conversationId: b.conversationId, by: s.user.id, at: new Date() });
  }

  /** Staff-only: list conversations (manager sees own clients, admin sees all) */
  @UseGuards(WsRoleGuard(['manager', 'admin', 'superadmin']))
  @SubscribeMessage('inbox:list')
  inbox(@ConnectedSocket() s: AuthedSocket, @MessageBody() b: { cursor?: string }) {
    return this.chat.inbox(s.user, b.cursor);
  }

  /** Client: turn this chat into a support ticket */
  @SubscribeMessage('conversation:toTicket')
  toTicket(@ConnectedSocket() s: AuthedSocket, @MessageBody() b: { conversationId: string; subject: string }) {
    return this.chat.convertToTicket(s.user, b.conversationId, b.subject);
  }
}

function socket_join(s: AuthedSocket, conversationId: string) {
  // Leave any other conv rooms so a socket only streams one thread at a time
  [...s.rooms].filter(r => r.startsWith('conv:')).forEach(r => s.leave(r));
  s.join(`conv:${conversationId}`);
}
