import { Injectable } from '@nestjs/common';
import { RedisService } from '../redis/redis.service';

/** Online = at least one live socket. Key expires if a heartbeat is missed (crash safety). */
@Injectable()
export class PresenceService {
  private TTL = 70; // seconds; client pings every 25s

  constructor(private redis: RedisService) {}

  async online(userId: string) {
    await this.redis.client.multi().incr(`presence:${userId}`).expire(`presence:${userId}`, this.TTL).exec();
  }

  async heartbeat(userId: string) {
    await this.redis.client.expire(`presence:${userId}`, this.TTL);
  }

  /** Returns true if user still has other sockets open */
  async offline(userId: string, _socketId: string): Promise<boolean> {
    const n = await this.redis.client.decr(`presence:${userId}`);
    if (n <= 0) { await this.redis.client.del(`presence:${userId}`); return false; }
    return true;
  }

  async isOnline(userId: string) {
    return (await this.redis.client.exists(`presence:${userId}`)) === 1;
  }
}
