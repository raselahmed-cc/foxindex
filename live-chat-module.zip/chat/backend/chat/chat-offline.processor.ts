import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Job } from 'bullmq';
import { MailService } from '../notifications/mail.service';
import { WhatsAppService } from '../notifications/whatsapp.service';
import { DrizzleService } from '../db/drizzle.service';
import { users } from '../db/schema';
import { eq } from 'drizzle-orm';

/** Runs when a chat message is sent to someone who is offline. jobId dedupes to one per 10 min per conversation. */
@Processor('notify')
export class ChatOfflineProcessor extends WorkerHost {
  constructor(private mail: MailService, private wa: WhatsAppService, private db: DrizzleService) { super(); }

  async process(job: Job) {
    if (job.name !== 'chat.offline') return;
    const { recipientId, senderName, body, conversationId } = job.data;
    const [r] = await this.db.q.select().from(users).where(eq(users.id, recipientId));
    if (!r) return;

    const preview = body.length > 120 ? body.slice(0, 117) + '…' : body;
    const link = `${process.env.WEB_ORIGIN}/chat?c=${conversationId}`;

    await this.mail.send(r.email, 'chat_new_message', { senderName, preview, link });
    if (r.whatsapp) await this.wa.sendTemplate(r.whatsapp, 'chat_new_message', [senderName, preview]);
  }
}
