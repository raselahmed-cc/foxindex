import { Injectable, ForbiddenException, NotFoundException } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { DrizzleService } from '../db/drizzle.service';
import { chatConversations, chatMessages, users, tickets, ticketMessages } from '../db/schema';
import { and, desc, eq, isNull, or, sql } from 'drizzle-orm';
import { RedisService } from '../redis/redis.service';

type User = { id: string; role: string; name: string; managerId?: string };

@Injectable()
export class ChatService {
  constructor(
    private db: DrizzleService,
    private redis: RedisService,
    @InjectQueue('notify') private notify: Queue,
  ) {}

  /** Who is on the other side of this user's conversations (for presence fan-out) */
  async peerIdsFor(userId: string, role: string): Promise<string[]> {
    if (role === 'client') {
      const [u] = await this.db.q.select({ m: users.assignedManagerId }).from(users).where(eq(users.id, userId));
      return u?.m ? [u.m] : [];
    }
    const rows = await this.db.q.select({ id: users.id }).from(users).where(eq(users.assignedManagerId, userId));
    return rows.map(r => r.id);
  }

  /** Open (or create) the single conversation for a client. Staff pass clientId; clients pass nothing. */
  async openConversation(user: User, body: { conversationId?: string; clientId?: string }) {
    const clientId = user.role === 'client' ? user.id : body.clientId;
    if (!clientId) throw new NotFoundException('clientId required');

    await this.assertCanAccessClient(user, clientId);

    let [conv] = await this.db.q.select().from(chatConversations).where(eq(chatConversations.userId, clientId));
    if (!conv) {
      const [client] = await this.db.q.select({ m: users.assignedManagerId }).from(users).where(eq(users.id, clientId));
      [conv] = await this.db.q.insert(chatConversations)
        .values({ userId: clientId, managerId: client?.m ?? null })
        .returning();
    }
    return conv;
  }

  async history(conversationId: string, limit = 50) {
    const rows = await this.db.q.select().from(chatMessages)
      .where(eq(chatMessages.conversationId, conversationId))
      .orderBy(desc(chatMessages.createdAt)).limit(limit);
    return rows.reverse();
  }

  async sendMessage(user: User, conversationId: string, body: string, attachments: any[]) {
    const [conv] = await this.db.q.select().from(chatConversations).where(eq(chatConversations.id, conversationId));
    if (!conv) throw new NotFoundException();
    await this.assertCanAccessClient(user, conv.userId);

    const recipientId = user.id === conv.userId ? conv.managerId : conv.userId;

    const [msg] = await this.db.q.insert(chatMessages)
      .values({ conversationId, senderId: user.id, body, attachments })
      .returning();
    await this.db.q.update(chatConversations)
      .set({ lastMessageAt: new Date(), isOpen: true })
      .where(eq(chatConversations.id, conversationId));

    if (recipientId) await this.redis.client.hincrby(`unread:${recipientId}`, conversationId, 1);

    return { ...msg, senderName: user.name, recipientId };
  }

  async markRead(conversationId: string, userId: string) {
    await this.db.q.update(chatMessages)
      .set({ readAt: new Date() })
      .where(and(eq(chatMessages.conversationId, conversationId), isNull(chatMessages.readAt), sql`${chatMessages.senderId} <> ${userId}`));
    await this.redis.client.hdel(`unread:${userId}`, conversationId);
  }

  async unreadCounts(userId: string, _role: string) {
    const h = await this.redis.client.hgetall(`unread:${userId}`);
    return Object.fromEntries(Object.entries(h).map(([k, v]) => [k, Number(v)]));
  }

  /** Manager inbox: own clients only; admins see everything */
  async inbox(user: User, cursor?: string) {
    const where = user.role === 'manager'
      ? eq(chatConversations.managerId, user.id)
      : undefined;
    const rows = await this.db.q.select({
        id: chatConversations.id, userId: chatConversations.userId,
        clientName: users.name, lastMessageAt: chatConversations.lastMessageAt, isOpen: chatConversations.isOpen,
      })
      .from(chatConversations).innerJoin(users, eq(users.id, chatConversations.userId))
      .where(where).orderBy(desc(chatConversations.lastMessageAt)).limit(30);
    const unread = await this.unreadCounts(user.id, user.role);
    return rows.map(r => ({ ...r, unread: unread[r.id] ?? 0 }));
  }

  /** Copy the thread into a new ticket so it gets SLA tracking */
  async convertToTicket(user: User, conversationId: string, subject: string) {
    const [conv] = await this.db.q.select().from(chatConversations).where(eq(chatConversations.id, conversationId));
    await this.assertCanAccessClient(user, conv.userId);
    const msgs = await this.history(conversationId, 200);

    return this.db.q.transaction(async tx => {
      const [t] = await tx.insert(tickets)
        .values({ userId: conv.userId, assignedTo: conv.managerId, subject, category: 'other' })
        .returning();
      await tx.insert(ticketMessages).values(
        msgs.map(m => ({ ticketId: t.id, senderId: m.senderId, body: m.body, attachments: m.attachments, createdAt: m.createdAt })),
      );
      return t;
    });
  }

  async notifyOffline(msg: { recipientId: string; body: string; conversationId: string; senderName: string }) {
    if (!msg.recipientId) return;
    // Debounced in the worker: one email/WhatsApp per conversation per 10 min
    await this.notify.add('chat.offline', msg, {
      jobId: `chat-offline:${msg.conversationId}:${Math.floor(Date.now() / 600000)}`,
    });
  }

  private async assertCanAccessClient(user: User, clientId: string) {
    if (user.role === 'admin' || user.role === 'superadmin') return;
    if (user.role === 'client' && user.id === clientId) return;
    if (user.role === 'manager') {
      const [c] = await this.db.q.select({ m: users.assignedManagerId }).from(users).where(eq(users.id, clientId));
      if (c?.m === user.id) return;
    }
    throw new ForbiddenException();
  }
}
